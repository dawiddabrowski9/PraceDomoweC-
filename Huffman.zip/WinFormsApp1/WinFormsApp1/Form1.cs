using System.DirectoryServices.ActiveDirectory;
using System.Reflection.Metadata.Ecma335;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

      

        private Dictionary<char,int> FrequencyTable(string text)
        {
            return text.GroupBy(c => c).ToDictionary(g => g.Key, g => g.Count());

        }

        static NodeG Tree(Dictionary<char,int> Dict)
        {
            var nodes = new List<NodeG>();
            foreach(var i in Dict)
            {
                nodes.Add(new NodeGS(i.Key,i.Value));
            }

            while(nodes.Count > 1)
            {
                nodes.Sort((x, y) => x.data.CompareTo(y.data));

                var left = nodes[0];
                var right = nodes[1];



                var newNode = new NodeG(left.data + right.data)
                {
                   left = left, right = right
                };

                left.parent = newNode;
                right.parent = newNode;
                nodes.RemoveAt(0);
                nodes.RemoveAt(0);
                nodes.Add(newNode);

            }
            return nodes[0];//root
        }
        static void Codes(NodeG node, string text,Dictionary<char,string> Dict)
        {
            if (node == null) return;
            if(node is NodeGS character)
            {
                Dict[character.Letter] = text;
            }
            Codes(node.left, text + "0", Dict);
            Codes(node.right, text + "1", Dict);


        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

       


        private void Huffman_Click(object sender, EventArgs e)
        {
            string text = textBox1.Text;
            Dictionary<char, int> dict = FrequencyTable(text);
            label2.Text = string.Join(Environment.NewLine, dict.Select(i => $"{i.Key}:{i.Value}"));
            NodeG root = Tree(dict);
            Dictionary<char, string> result = new Dictionary<char, string>();
            Codes(root, "", result);
            label1.Text = string.Join(Environment.NewLine, result.Select(i => $"{i.Key}:{i.Value}"));
        }   
    }
}
