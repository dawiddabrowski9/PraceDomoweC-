﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    internal class NodeG
    {
        public NodeG left { get; set; }
        public NodeG right { get; set; }
        public NodeG parent { get; set; }
        public int data { get; set; }

        public NodeG(int data)
        {
            data = data;
        }
    }
}
