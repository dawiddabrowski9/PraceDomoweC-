﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    internal class NodeGS: NodeG
    {
        public char Letter { get; set; }
        public NodeGS(char character,int data):base(data) {
            Letter = character;
        }
    }
}
