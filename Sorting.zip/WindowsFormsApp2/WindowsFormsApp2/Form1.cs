﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{

    public partial class Form1 : Form
    {

        public int[] tablica= new int[0];
        private object label1Result;
        

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string liczby = textBox1.Text;

       
            string[] tablicaPrzedKonwertem = liczby.Split(',');

            
            int nowaWielkosc = tablica.Length + tablicaPrzedKonwertem.Length;
            int[] pomTablica = new int[nowaWielkosc];

            
            for (int i = 0; i < tablica.Length; i++)
            {
                pomTablica [i] = tablica [i];
            }

            
            for (int i = 0; i < tablicaPrzedKonwertem.Length; i++)
            {
                int a;
                if (int.TryParse(tablicaPrzedKonwertem[i].Trim(), out a)) 
                {
                    
                    pomTablica[tablica.Length + i] = a;
                }
                else
                {
                    
                    MessageBox.Show($"'{tablicaPrzedKonwertem[i]}' nie jest prawidłową liczbą.");
                }
            }

            
            tablica = pomTablica;

            
            textBox1.Clear();
            label3.Text = "Utworzona tablica: " + string.Join(", ", tablica);
        }
    

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            
        }

    
        // Losowe generowanie tablicy
        private void button2_Click(object sender, EventArgs e)
        {
            int dlugosc = (int)numericUpDown1.Value;
            tablica  = new int[dlugosc];

            Random random = new Random();
            for (int i = 0; i < dlugosc; i++)
            {
                tablica[i] = random.Next(1, 100);
            }
            MessageBox.Show("Tablica utworzona!");
            label2.Text = "Utworzona tablica: " + string.Join(", ", tablica);
        }
        //Bubble Sort
        private void BubbleSort(int[] tablica){
            int pom;
            for (int i = 0; i < tablica.Length; i++)
            {
                for (int j = 0; j < tablica.Length - i - 1; j++)
                {
                    if (tablica[j + 1] < tablica[j])
                    {
                        pom = tablica[j];
                        tablica[j] = tablica[j + 1];
                        tablica[j + 1] = pom;
                    }
                }
            }
        }
        
        private void button3_Click(object sender, EventArgs e)
        {
            if (tablica == null || tablica.Length == 0)
            {
                MessageBox.Show("Najpierw wygeneruj tablice!");
                
            }
            else
            {
                BubbleSort(tablica);
                label1.Text = "Posortowana tablica: " + string.Join(", ", tablica);
            }
        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        //Insertion Sort
        private void InsertionSort(int[] tablica)
        {
            int pom;
            for (int i = 0; i < tablica.Length; i++)
            {
                int j = i;
                while(j>0 && tablica[j - 1] > tablica[j])
                {
                    pom = tablica[j];
                    tablica[j]=tablica[j-1];
                    tablica[j-1] = pom;
                    j--;
                }
             
            }

        }
        private void button6_Click(object sender, EventArgs e)
        {
            if (tablica == null || tablica.Length == 0)
            {
                MessageBox.Show("Najpierw wygeneruj tablice!");

            }
            else
            {
                InsertionSort(tablica);
                label1.Text = "Posortowana tablica: " + string.Join(", ", tablica);
            }
        }
        static void Podmiana(int[] tablica, int i, int j)
        {
            int pom = tablica[i];
            tablica[i] = tablica[j];
            tablica[j] = pom;
        }
        static int Dziel(int[] tablica, int p, int q)
        {
            int strzalka = tablica[q]; 
            int i = p - 1; 

            for (int j = p; j < q; j++)
            {
                if (tablica[j] <= strzalka)
                {
                    i++;
                    Podmiana(tablica, i, j); 
                }
            }

            Podmiana(tablica, i + 1, q); 
            return i + 1;
        }
        static void QuickSort1(int[] tablica, int a, int b)
        {
            if (a < b)
            {
                int pozycjaStrzalki = Dziel(tablica, a, b);
                QuickSort1(tablica, a, pozycjaStrzalki - 1);
                QuickSort1(tablica, pozycjaStrzalki + 1, b);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (tablica == null || tablica.Length == 0)
            {
                MessageBox.Show("Najpierw wygeneruj tablice!");

            }
            else
            {
                QuickSort1(tablica,0,tablica.Length-1);
                label1.Text = "Posortowana tablica: " + string.Join(", ", tablica);
            }
        }
        static void MergeSort(int[] tablica, int p, int q, int r)
        {
            int a = q - p + 1;
            int b = r - q;

            int[] lewa = new int[a];
            int[] prawa = new int[b];

            for (int i = 0; i < a; i++)
                lewa[i] = tablica[p + i];
            for (int j = 0; j < b; j++)
                prawa[j] = tablica[q + 1 + j];

            
            int lewaIndeks = 0, prawaIndeks = 0;


            int Indeks = p;

            
            while (lewaIndeks < a && prawaIndeks < b)
            {
                if (lewa[lewaIndeks] <= prawa[prawaIndeks])
                {
                    tablica[Indeks] = lewa[lewaIndeks];
                    lewaIndeks++;
                }
                else
                {
                    tablica[Indeks] = prawa[prawaIndeks];
                    prawaIndeks++;
                }
                Indeks++;
            }

            while (lewaIndeks < a)
            {
                tablica[Indeks] = lewa[lewaIndeks];
                lewaIndeks++;
                Indeks++;
            }

            while (prawaIndeks < b)
            {
                tablica[Indeks] = prawa[prawaIndeks];
                prawaIndeks++;
                Indeks++;
            }
        }
        static void MergeSort1(int[] tablica, int p, int q)
        {
            if (p < q)
            { 
                int r = (p + q) / 2;
                MergeSort1(tablica, p, r);
                MergeSort1(tablica, r + 1, q);
                MergeSort(tablica, p, r, q);
            }
        }
       
        private void button5_Click(object sender, EventArgs e)
        {
            if (tablica == null || tablica.Length == 0)
            {
                MessageBox.Show("Najpierw wygeneruj tablice!");

            }
            else
            {
                MergeSort1(tablica, 0, tablica.Length - 1);
                label1.Text = "Posortowana tablica: " + string.Join(", ", tablica);
            }
        }
        void countingSort(int[] tab)
        {
            int min = tab[0];
            int max = tab[0];
            for (int i = 0; i < tab.Length; i++)
            {
                if (tab[i] < min) min = tab[i];
                if (tab[i] > max) max = tab[i];
            }

            int[] count = new int[max + 1];

            foreach (int i in tab)
            {
                count[i]++;
            }
            int indeks = 0;
            for (int i = 0; i < count.Length; i++)
            {
                while (count[i] > 0)
                {
                    tab[indeks] = i;
                    indeks++;
                    count[i]--;
                }
            }
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            if (tablica == null || tablica.Length == 0)
            {
                MessageBox.Show("Najpierw wygeneruj tablice!");

            }
            else
            {
                countingSort(tablica);
                label1.Text = "Posortowana tablica: " + string.Join(", ", tablica);
            }
        }
    }
}
